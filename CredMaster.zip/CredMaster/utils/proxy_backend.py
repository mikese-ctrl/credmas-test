"""
Proxy backend abstraction for CredMaster.

Defines the common interface that every proxy backend (OmniProx, FireProx, ...)
must implement so that credmaster.py can remain backend-agnostic.

Each created proxy is represented as a dict with the keys:
    {
        "api_gateway_id": <str>,   # identifier used for deletion
        "proxy_url":      <str>,   # base URL plugins should spray against
        "region":         <str>,   # region/location (may be None)
    }
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Optional


class ProxyBackend(ABC):
    """Abstract base class for a CredMaster proxy backend."""

    name = "base"

    def __init__(self, args):
        self.args = args

    @abstractmethod
    def create_proxies(self, url: str, count: int, region: Optional[str] = None) -> List[Dict]:
        """Create `count` proxies pointing at `url`.

        Args:
            url: Target URL the proxies should forward to.
            count: Number of proxies to create (usually the thread count).
            region: Optional region/location hint.

        Returns:
            A list of proxy dicts (see module docstring for the shape).
        """
        raise NotImplementedError

    @abstractmethod
    def list_proxies(self) -> List[Dict]:
        """Return a list of currently active proxies for this backend."""
        raise NotImplementedError

    @abstractmethod
    def delete_proxy(self, api_id: str, region: Optional[str] = None) -> bool:
        """Delete a single proxy by its identifier."""
        raise NotImplementedError

    @abstractmethod
    def cleanup_all(self) -> int:
        """Delete all proxies managed by this backend.

        Returns:
            The number of proxies removed.
        """
        raise NotImplementedError
