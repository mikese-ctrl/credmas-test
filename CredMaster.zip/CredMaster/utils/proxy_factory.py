"""
Proxy backend factory for CredMaster.

Selects and instantiates the appropriate ProxyBackend implementation based
on the `--proxy_backend` option (default: omniprox).
"""

from utils.proxy_backend import ProxyBackend


def get_backend(name, args) -> ProxyBackend:
    """Return an initialised ProxyBackend for the given backend name.

    Args:
        name: Backend identifier ("omniprox" or "fireprox").
        args: Parsed CLI/config argument namespace.

    Returns:
        A ready-to-use ProxyBackend instance.

    Raises:
        ValueError: If the backend name is not recognised.
    """
    backend = (name or "omniprox").lower()

    if backend == "omniprox":
        from utils.proxy_omniprox import OmniProxBackend
        return OmniProxBackend(args)

    if backend == "fireprox":
        from utils.proxy_fireprox import FireProxBackend
        return FireProxBackend(args)

    raise ValueError(f"Unknown proxy backend: {name}")
