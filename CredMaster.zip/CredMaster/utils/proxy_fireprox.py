"""
FireProx backend for CredMaster.

Thin wrapper around the bundled utils.fire.FireProx implementation that
conforms to the ProxyBackend interface. This preserves the original
AWS API Gateway behaviour for users who still want to use FireProx via
`--proxy_backend fireprox`.
"""

from typing import List, Dict, Optional

from utils.fire import FireProx
from utils.proxy_backend import ProxyBackend


# AWS regions FireProx can deploy API Gateways into (matches the original
# credmaster.py region list).
AWS_REGIONS = [
    "us-east-2", "us-east-1", "us-west-1", "us-west-2", "eu-west-3",
    "ap-northeast-1", "ap-northeast-2", "ap-south-1",
    "ap-southeast-1", "ap-southeast-2", "ca-central-1",
    "eu-central-1", "eu-west-1", "eu-west-2", "sa-east-1",
]


class FireProxBackend(ProxyBackend):
    """AWS API Gateway (FireProx) proxy backend."""

    name = "fireprox"

    def __init__(self, args):
        super().__init__(args)
        self.access_key = getattr(args, "access_key", None)
        self.secret_access_key = getattr(args, "secret_access_key", None)
        self.session_token = getattr(args, "session_token", None)
        self.profile_name = getattr(args, "profile_name", None)
        self.regions = AWS_REGIONS

    def _fp_args(self, command, region, url=None, api_id=None):
        args = {
            "access_key": self.access_key,
            "secret_access_key": self.secret_access_key,
            "session_token": self.session_token,
            "profile_name": self.profile_name,
            "url": url,
            "command": command,
            "region": region,
            "api_id": api_id,
        }
        help_str = "Error, inputs cause error."
        return args, help_str

    def _create_single(self, region, url):
        args, help_str = self._fp_args("create", region, url=url)
        fp = FireProx(args, help_str)
        resource_id, proxy_url = fp.create_api(url)
        return {"api_gateway_id": resource_id, "proxy_url": proxy_url, "region": region}

    def create_proxies(self, url: str, count: int, region: Optional[str] = None) -> List[Dict]:
        if count > len(self.regions):
            count = len(self.regions)

        proxies = []
        # Serial creation - multithreading causes errors in boto3.
        for x in range(0, count):
            reg = region if region is not None else self.regions[x]
            proxies.append(self._create_single(reg, url.strip()))
        return proxies

    def list_proxies(self) -> List[Dict]:
        results = []
        for region in self.regions:
            args, help_str = self._fp_args("list", region)
            fp = FireProx(args, help_str)
            active_apis = fp.list_api()
            for api in active_apis:
                results.append({
                    "api_gateway_id": api["id"],
                    "name": api.get("name", ""),
                    "createdDate": api.get("createdDate", ""),
                    "region": region,
                })
        return results

    def delete_proxy(self, api_id: str, region: Optional[str] = None) -> bool:
        regions = [region] if region is not None else self.regions
        for reg in regions:
            args, help_str = self._fp_args("list", reg)
            fp = FireProx(args, help_str)
            active_apis = fp.list_api()
            for api in active_apis:
                if api["id"] == api_id:
                    args, help_str = self._fp_args("delete", reg, api_id=api_id)
                    fp = FireProx(args, help_str)
                    fp.delete_api(api_id)
                    return True
        return False

    def cleanup_all(self) -> int:
        clear_count = 0
        for region in self.regions:
            args, help_str = self._fp_args("list", region)
            fp = FireProx(args, help_str)
            active_apis = fp.list_api()
            for api in active_apis:
                if "fireprox" in api["name"]:
                    fp.delete_api(api["id"])
                    clear_count += 1
        return clear_count
