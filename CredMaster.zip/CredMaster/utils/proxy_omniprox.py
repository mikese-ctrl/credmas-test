"""
OmniProx backend for CredMaster.

Adapter that drives OmniProx provider classes (Azure, GCP, Cloudflare,
Alibaba) through the common ProxyBackend interface so OmniProx can act as
the default proxy backend for CredMaster.

Azure (the CredMaster default) creates a pool of Container Instances, each
with its own public IP, in a single `create` call using `--number`.
"""

import argparse
from typing import List, Dict, Optional

from utils.proxy_backend import ProxyBackend


# Normalise provider aliases to OmniProx canonical names.
PROVIDER_ALIASES = {
    "cf": "cloudflare",
    "az": "azure",
}


class OmniProxError(Exception):
    """Raised when the OmniProx backend cannot be used."""


class OmniProxBackend(ProxyBackend):
    """Backend that delegates proxy lifecycle to OmniProx providers."""

    name = "omniprox"

    def __init__(self, args):
        super().__init__(args)

        provider = getattr(args, "provider", None) or "azure"
        self.provider = PROVIDER_ALIASES.get(provider, provider)
        self.profile = getattr(args, "profile", None) or "default"
        self.region = getattr(args, "region", None)

        try:
            from omniprox.cli import get_provider_class
        except ImportError as ex:
            raise OmniProxError(
                "OmniProx is not installed. Install it with:\n"
                "  pip install git+https://github.com/ZephrFish/OmniProx.git"
            ) from ex

        self._get_provider_class = get_provider_class

        provider_class = self._get_provider_class(self.provider)
        if provider_class is None:
            raise OmniProxError(
                f"OmniProx provider '{self.provider}' is not available. "
                f"Ensure the required SDK packages are installed."
            )
        self._provider_class = provider_class

    # ---- internal helpers -------------------------------------------------

    def _build_args(self, command, url=None, api_id=None, number=None):
        """Construct an argparse.Namespace shaped the way OmniProx expects."""
        return argparse.Namespace(
            provider=self.provider,
            profile=self.profile,
            command=command,
            url=url,
            api_id=api_id,
            number=number if number is not None else 1,
            region=self.region,
            auto_create=False,
            debug=getattr(self.args, "debug", False),
            quiet=False,
        )

    def _new_provider(self, command, url=None, api_id=None, number=None):
        args = self._build_args(command, url=url, api_id=api_id, number=number)
        return self._provider_class(args)

    @staticmethod
    def _suppress_confirm(provider):
        """Disable OmniProx's interactive confirm prompts for this module."""
        import sys
        module_name = type(provider).__module__
        module = sys.modules.get(module_name)
        if module is not None and hasattr(module, "confirm_action"):
            module.confirm_action = lambda *a, **kw: True

    def _extract_proxies(self, provider) -> List[Dict]:
        """Pull structured proxy info off a provider after a create() call.

        Different providers expose created endpoints via different attributes.
        We check the known ones in order of preference.
        """
        proxies = []

        # Azure: list of {name, ip, fqdn, url, target}
        pool = getattr(provider, "container_pool", None)
        if pool:
            for entry in pool:
                proxies.append({
                    "api_gateway_id": entry.get("name"),
                    "proxy_url": entry.get("url"),
                    "region": getattr(provider, "location", self.region),
                    "ip": entry.get("ip"),
                })
            return proxies

        # Alibaba / template style: list of {proxy_url, ...}
        apis = getattr(provider, "apis", None)
        if apis:
            for entry in apis:
                proxies.append({
                    "api_gateway_id": entry.get("id") or entry.get("name"),
                    "proxy_url": entry.get("proxy_url") or entry.get("url"),
                    "region": entry.get("region", self.region),
                })
            return proxies

        # Cloudflare: endpoints persisted to a JSON file
        if hasattr(provider, "_load_endpoints"):
            try:
                for entry in provider._load_endpoints():
                    proxies.append({
                        "api_gateway_id": entry.get("name"),
                        "proxy_url": entry.get("url"),
                        "region": self.region,
                    })
                if proxies:
                    return proxies
            except Exception:
                pass

        # Last resort: single most-recent proxy URL
        if hasattr(provider, "_get_last_created_proxy_url"):
            url = provider._get_last_created_proxy_url()
            if url:
                proxies.append({
                    "api_gateway_id": None,
                    "proxy_url": url,
                    "region": self.region,
                })

        return proxies

    # ---- ProxyBackend interface ------------------------------------------

    def create_proxies(self, url: str, count: int, region: Optional[str] = None) -> List[Dict]:
        if region is not None:
            self.region = region

        provider = self._new_provider("create", url=url, number=count)
        success = provider.execute()
        if not success:
            raise OmniProxError(
                f"OmniProx {self.provider} failed to create proxies. "
                f"Check credentials with 'omniprox --provider {self.provider} --command status'."
            )

        proxies = self._extract_proxies(provider)
        if not proxies:
            raise OmniProxError(
                f"OmniProx {self.provider} reported success but no proxy URLs "
                f"could be determined."
            )
        return proxies

    def list_proxies(self) -> List[Dict]:
        provider = self._new_provider("list")
        provider.execute()
        # Best-effort structured return (providers primarily print to stdout).
        return self._extract_proxies(provider)

    def delete_proxy(self, api_id: str, region: Optional[str] = None) -> bool:
        if region is not None:
            self.region = region
        provider = self._new_provider("delete", api_id=api_id)
        return bool(provider.execute())

    def cleanup_all(self) -> int:
        provider = self._new_provider("cleanup")
        self._suppress_confirm(provider)
        result = provider.execute()
        return 0 if result is False else 1
